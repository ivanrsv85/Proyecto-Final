from flask import Flask, render_template, request, send_from_directory
from models import prediction
import pandas as pd

app = Flask(__name__, static_url_path='/static')

@app.route("/" , methods=['GET'])
def index():
    return render_template("index.html")

@app.route("/predict" , methods=['GET'])
def predict():
    valor = request.args.get('valor')
    tasa = request.args.get('tasa')
    plazo = request.args.get('plazo')
    cliente = request.args.get('cliente')
    destinacion = request.args.get('destinacion')
    canal = request.args.get('canal')
    empresa = request.args.get('empresa')
    ano = request.args.get('ano')
    actividad = request.args.get('actividad')
    ciudad = request.args.get('ciudad')
    estrato = request.args.get('estrato')
    acceso = request.args.get('acceso')
    mujeres = request.args.get('mujeres')
    garantia = request.args.get('garantia')

    if tasa != "":
        tasa = float(tasa)
    else:
        tasa = 0

    if ano != "":
        ano = int(ano)
    else:
        ano = 0

    if estrato != "":
        estrato = int(estrato)
    else:
        estrato = 0

    valores = [[valor, tasa, plazo, cliente, destinacion, canal, empresa, ano, actividad, ciudad, estrato,
               acceso, mujeres, garantia]]
    df = pd.DataFrame(valores, columns=['Valor_OK', 'Tasa_de_Interes', 'Plazo_OK', 'Cliente', 'Producto_Destinacion_OK',
               'Canal_de_Captura_OK', 'Tipo_de_Empresa', 'Ano_de_Constitucion', 'Actividad_eco_SEMPLI', 'Ciudad_agrupada',
               'Estrato', 'Acceso_a_la_banca', 'Mujeres_Empresarias', 'Tipo_de_Garantia'])
    result = prediction(df)
    rel_str = ""
    if result[0] == 1:
        rel_str = "El cliente prospecto incurrirá en mora"
    else:
        rel_str = "El cliente prospecto No incurrirá en mora"
    return render_template("predict.html", result=result[0], result_str=rel_str)


if __name__ == "__main__":
    app.run()

# if __name__ == "__main__":
#     app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))